import { SignIn } from '@clerk/nextjs'

export default function SignInPage() {
  return (
    <main className="min-h-screen bg-black flex items-center justify-center">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div style={{fontFamily: 'Ruthie, cursive', fontSize: '2rem', color: '#7BC906', marginBottom: '8px'}}>
            studio 2.5
          </div>
          <div style={{fontFamily: 'Hedvig Letters Serif, serif', fontSize: '0.875rem', color: 'rgba(255,255,255,0.5)'}}>
            advisor · sign in to continue
          </div>
        </div>
        <SignIn
          appearance={{
            elements: {
              rootBox: 'w-full',
              card: 'bg-[#0a1002] border border-[#7BC906]/20 shadow-xl',
              headerTitle: 'text-white font-semibold',
              headerSubtitle: 'text-white/50',
              socialButtonsBlockButton: 'border border-white/20 text-white hover:bg-white/5',
              socialButtonsBlockButtonText: 'text-white/70',
              dividerLine: 'bg-white/10',
              dividerText: 'text-white/30',
              formFieldLabel: 'text-white/60 text-xs',
              formFieldInput: 'bg-white/5 border-white/20 text-white',
              formButtonPrimary: 'bg-[#7BC906] text-[#121f04] font-bold hover:opacity-90',
              footerActionLink: 'text-[#7BC906]',
            },
          }}
        />
      </div>
    </main>
  )
}
